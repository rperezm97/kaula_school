import { useEffect, useRef, useState, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Link, useParams } from "wouter";
import { Loader2, ArrowLeft, Bookmark, BookmarkCheck, Play, FileText, ChevronRight } from "lucide-react";
import { toast } from "sonner";

export default function VideoPlayer() {
  const { slug } = useParams<{ slug: string }>();
  const { loading } = useAuth();
  const videoQuery = trpc.courses.videoBySlug.useQuery({ slug: slug || "" }, { enabled: !!slug });
  const progressQuery = trpc.progress.videoProgress.useQuery(
    { videoId: videoQuery.data?.id ?? 0 },
    { enabled: !!videoQuery.data?.id }
  );
  const bookmarksQuery = trpc.bookmarks.list.useQuery();
  const updateProgress = trpc.progress.update.useMutation();
  const toggleBookmark = trpc.bookmarks.toggle.useMutation({
    onSuccess: (data) => {
      toast.success(data.isBookmarked ? "Bookmarked" : "Bookmark removed");
      bookmarksQuery.refetch();
    },
  });

  const [playbackRate] = useState(1);
  const progressInterval = useRef<ReturnType<typeof setInterval> | null>(null);
  const [watchedSeconds, setWatchedSeconds] = useState(0);

  // Track progress periodically
  useEffect(() => {
    if (!videoQuery.data?.id) return;
    progressInterval.current = setInterval(() => {
      setWatchedSeconds(prev => {
        const newVal = prev + 10;
        updateProgress.mutate({
          videoId: videoQuery.data!.id,
          watchedSeconds: newVal,
          completed: videoQuery.data!.durationSeconds ? newVal >= videoQuery.data!.durationSeconds * 0.9 : false,
        });
        return newVal;
      });
    }, 10000);
    return () => { if (progressInterval.current) clearInterval(progressInterval.current); };
  }, [videoQuery.data?.id]);

  // Restore progress
  useEffect(() => {
    if (progressQuery.data?.watchedSeconds) {
      setWatchedSeconds(progressQuery.data.watchedSeconds);
    }
  }, [progressQuery.data]);

  const isBookmarked = useMemo(() => {
    if (!bookmarksQuery.data || !videoQuery.data) return false;
    return bookmarksQuery.data.some(b => b.videoId === videoQuery.data!.id);
  }, [bookmarksQuery.data, videoQuery.data]);

  if (loading || videoQuery.isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  const video = videoQuery.data;
  if (!video) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Video not found</p>
          <Link href="/courses"><Button variant="outline" className="border-primary/30 text-primary">Back to Courses</Button></Link>
        </div>
      </div>
    );
  }

  // Build Google Drive embed URL
  const getEmbedUrl = () => {
    if (video.googleDriveFileId) {
      return `https://drive.google.com/file/d/${video.googleDriveFileId}/preview`;
    }
    if (video.googleDriveUrl) {
      // Extract file ID from various Google Drive URL formats
      const match = video.googleDriveUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
      if (match) return `https://drive.google.com/file/d/${match[1]}/preview`;
      return video.googleDriveUrl;
    }
    return null;
  };

  const embedUrl = getEmbedUrl();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/50 bg-background/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href={video.sectionSlug ? `/courses/${video.sectionSlug}` : "/courses"}>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="font-serif text-lg tracking-wide text-foreground truncate">{video.title}</h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => toggleBookmark.mutate({ videoId: video.id })}
            className={isBookmarked ? "text-primary" : "text-muted-foreground hover:text-primary"}
          >
            {isBookmarked ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      <div className="container py-8 max-w-5xl mx-auto">
        {/* Video Player */}
        <div className="relative bg-black rounded-xl overflow-hidden mb-8 aspect-video">
          {embedUrl ? (
            <iframe
              src={embedUrl}
              className="w-full h-full"
              allow="autoplay; encrypted-media"
              allowFullScreen
              sandbox="allow-scripts allow-same-origin allow-popups"
              style={{ border: "none" }}
              onContextMenu={(e) => e.preventDefault()}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-center">
                <Play className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
                <p className="text-muted-foreground">No video source configured</p>
                <p className="text-muted-foreground/60 text-sm mt-1">Admin needs to add a Google Drive link</p>
              </div>
            </div>
          )}
        </div>

        {/* Subtitle info */}
        {video.subtitleUrl && (
          <div className="mb-4 text-xs text-muted-foreground">
            <a href={video.subtitleUrl} target="_blank" rel="noopener noreferrer" className="hover:text-primary">
              Download subtitles (.vtt)
            </a>
          </div>
        )}

        {/* Video Info */}
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="font-serif text-2xl text-foreground tracking-wide mb-3">{video.title}</h2>
            {video.description && (
              <div className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{video.description}</div>
            )}

            {/* Attached Resources */}
            {video.resources && video.resources.length > 0 && (
              <div className="mt-8">
                <h3 className="font-serif text-lg text-foreground tracking-wide mb-3">Resources</h3>
                <div className="space-y-2">
                  {video.resources.map((res: any) => (
                    <a key={res.id} href={res.fileUrl} target="_blank" rel="noopener noreferrer" className="block">
                      <div className="bg-card/50 border border-border/50 rounded-lg p-3 hover:border-primary/40 transition-all flex items-center gap-3">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-foreground">{res.title}</span>
                        <span className="text-xs text-muted-foreground uppercase ml-auto">{res.fileType}</span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Related Videos */}
          <div>
            {video.relatedVideos && video.relatedVideos.length > 0 && (
              <div>
                <h3 className="font-serif text-lg text-foreground tracking-wide mb-3">Related</h3>
                <div className="space-y-2">
                  {video.relatedVideos.map((related: any) => (
                    <Link key={related.id} href={`/video/${related.slug}`}>
                      <div className="bg-card/50 border border-border/50 rounded-lg p-3 hover:border-primary/40 transition-all cursor-pointer flex items-center gap-3">
                        <Play className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-sm text-foreground truncate">{related.title}</span>
                        <ChevronRight className="h-4 w-4 text-muted-foreground ml-auto flex-shrink-0" />
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
