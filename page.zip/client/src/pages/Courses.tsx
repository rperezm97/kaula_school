import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { Loader2, Compass, BookOpen, Sparkles, Eye, Video, FolderOpen, Search, Bookmark, Settings, LogOut, Shield } from "lucide-react";

const YANTRA_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663440106934/Z38f2pvPBxWeP9byuWrrSZ/yantra-hero-mS4hu6TMqj5gR8ntzMg4SC.webp";

const ICON_MAP: Record<string, React.ReactNode> = {
  Compass: <Compass className="h-6 w-6" />,
  BookOpen: <BookOpen className="h-6 w-6" />,
  Sparkles: <Sparkles className="h-6 w-6" />,
  Eye: <Eye className="h-6 w-6" />,
  Video: <Video className="h-6 w-6" />,
  FolderOpen: <FolderOpen className="h-6 w-6" />,
};

export default function Courses() {
  const { user, loading, logout } = useAuth();
  const [, setLocation] = useLocation();
  const sectionsQuery = trpc.courses.sections.useQuery();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>;
  }

  const handleLogout = async () => {
    await logout();
    setLocation("/", { replace: true });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/50">
        <div className="container flex items-center justify-between py-3">
          <Link href="/">
            <div className="flex items-center gap-3">
              <img src={YANTRA_URL} alt="" className="w-8 h-8 opacity-70" />
              <span className="font-serif text-lg tracking-widest text-primary">KAULA SCHOOL</span>
            </div>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/search">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary"><Search className="h-5 w-5" /></Button>
            </Link>
            <Link href="/bookmarks">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary"><Bookmark className="h-5 w-5" /></Button>
            </Link>
            {user?.role === "admin" && (
              <Link href="/admin">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary"><Shield className="h-5 w-5" /></Button>
              </Link>
            )}
            <Link href="/settings">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary"><Settings className="h-5 w-5" /></Button>
            </Link>
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <div className="container py-12 text-center">
        <h1 className="font-serif text-3xl tracking-wider text-foreground mb-2">Course Library</h1>
        <p className="text-muted-foreground text-sm">Welcome{user?.name ? `, ${user.name}` : ""}. Choose a section to begin.</p>
      </div>

      {/* Section Grid */}
      <div className="container pb-20">
        {sectionsQuery.isLoading ? (
          <div className="flex justify-center py-20"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl">
            {sectionsQuery.data?.filter(s => !s.parentId).map((section) => (
              <Link key={section.id} href={`/courses/${section.slug}`}>
                <div className="bg-card border border-border/50 rounded-xl p-6 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/10 transition-all duration-300 group cursor-pointer h-full">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 text-primary group-hover:bg-primary/20 transition-colors">
                    {ICON_MAP[section.iconName || "FolderOpen"] || <FolderOpen className="h-6 w-6" />}
                  </div>
                  <h3 className="font-serif text-xl text-foreground tracking-wide mb-2 group-hover:text-primary transition-colors">
                    {section.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {section.description || "Explore this section"}
                  </p>
                </div>
              </Link>
            ))}

            {(!sectionsQuery.data || sectionsQuery.data.filter(s => !s.parentId).length === 0) && (
              <div className="col-span-full text-center py-20">
                <p className="text-muted-foreground">No sections available yet. The admin will add content soon.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
